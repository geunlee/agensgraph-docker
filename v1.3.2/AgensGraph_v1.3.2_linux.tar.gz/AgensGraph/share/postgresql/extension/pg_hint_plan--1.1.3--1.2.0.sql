/* pg_hint_plan/pg_hint_plan--1.1.3--1.2.0.sql */

-- complain if script is sourced in psql, rather than via CREATE EXTENSION
\echo Use "CREATE EXTENSION pg_hint_plan" to load this file. \quit

-- nothing to do upgrading from 1.1.3.
