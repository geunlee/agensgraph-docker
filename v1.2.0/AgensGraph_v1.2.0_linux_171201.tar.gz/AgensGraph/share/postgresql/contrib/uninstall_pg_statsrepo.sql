/*
 * bin/uninstall_pg_statsrepo.sql
 *
 * Copyright (c) 2009-2017, NIPPON TELEGRAPH AND TELEPHONE CORPORATION
 */

DROP SCHEMA IF EXISTS statsrepo CASCADE;
